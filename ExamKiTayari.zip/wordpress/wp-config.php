<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'database_name_here' );

/** MySQL database username */
define( 'DB_USER', 'username_here' );

/** MySQL database password */
define( 'DB_PASSWORD', 'password_here' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'AMmXrqX5JG3jkQPweu4wR^F!_*_@f@?(XE^rsmu& RmL`40k4--6Rab35(0zZ+cR');
define('SECURE_AUTH_KEY',  'SV4^.f|:L1#6m(;/PyQG4Cd1].*):pU=bxA0-R,)D=#f{_o8D}@K |[Y Bd;U5K3');
define('LOGGED_IN_KEY',    '8I/+SVN`^w3K=5W(Z9/%O(*aB G3 K^fsFUU##*&4E5(hYk|o-pY8_<#ft.FJ/;5');
define('NONCE_KEY',        '<;aFC`m&u0$w/jX*4+uRw}9agt|QQX?D@c5yA_a`V#>=sRV|MU)kyn6y4^o?AYlf');
define('AUTH_SALT',        'yBRML~_o7(zDR m=c(hQW&e551rd_ju1Ff<z|0>~7A(//|zUMco:2fbZ(:Q*vYf|');
define('SECURE_AUTH_SALT', 't&49kR|a^fi|%M~zNT;{x.?}([Cd8)`:&5{rzI>SH?#(JA%7gxdMqQ.jb/v/nC_[');
define('LOGGED_IN_SALT',   'Z+63Xd#+I+ews3]|b-r+V.c2Zhc!&Wb|dBsYbq5N9?OLIv4&!]&pH3(N<z}=ta5y');
define('NONCE_SALT',       '8jEaOjvTAVy#]=Q#KgD4P^daGH $pzIEpeYYTGhZ|5%6H|%<&-GZE2-AnubLZ[>;');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */

if ($_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') $_SERVER['HTTPS']='on';

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
